package com.service;

import com.entity.Admin;

public interface AdminService {
	public boolean registerAdmin(Admin admin);
	public Admin loginAdmin(String name ,String password);
}

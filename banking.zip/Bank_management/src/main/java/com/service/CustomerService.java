package com.service;

import org.springframework.stereotype.Service;

import com.entity.Customer;


@Service
public interface CustomerService {
	public boolean registerCustmore(Customer customer);
	public Customer loginCustomer(String adharno ,String password);
	public void AccountNo(char otp);
}


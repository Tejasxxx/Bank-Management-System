package com.service;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.entity.Customer;
import com.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	CustomerRepository customerRepo;

	@Override
	public boolean registerCustmore(Customer customer) {
		// TODO Auto-generated method stub
		try {
			customerRepo.save(customer);
		return true;
		}catch (Exception e){
			return false;
		}
	}

	@Override
	public Customer loginCustomer(String adharno, String password) {
		// TODO Auto-generated method stub
		Customer validuser=customerRepo.findByAdharno(adharno);
		if(validuser!=null && validuser.getPassword().equals(password)) {
			return validuser;
		}
		return null;
		
	}
	

	public void AccountNo(char acc_no) {
		int length = 15;
		String n = "0123456789";
		Random random = new Random();
		char[] acc_no1 = new char[length];
		for (int i = 0; i < length; i++) {
			acc_no1[i] = n.charAt(random.nextInt(n.length()));
		}
		return;
	}
	
}

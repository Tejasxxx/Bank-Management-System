package com.bank;

import java.awt.FlowLayout;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class BankSwingApp extends JFrame {

    private JTextField accountNumberField;
    private JLabel balanceLabel;

    public BankSwingApp() {
        setTitle("Bank Management");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        accountNumberField = new JTextField(15);
        balanceLabel = new JLabel("Balance:");

        JButton viewButton = new JButton("View Balance");
        viewButton.addActionListener(e -> viewBalance());

        add(new JLabel("Account Number:"));
        add(accountNumberField);
        add(viewButton);
        add(balanceLabel);

        setVisible(true);
    }

    private void viewBalance() {
        String accountNumber = accountNumberField.getText();
        // Call REST API to get account balance and display it
        try {
            URL url = new URL("http://localhost:8080/accounts/" + accountNumber);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String response = reader.readLine();
            balanceLabel.setText("Balance: " + response);
        } catch (Exception e) {
            balanceLabel.setText("Error fetching balance");
        }
    }

    public static void main(String[] args) {
        new BankSwingApp();
    }
}
